<?php
    // $Id: test_with_parse_error.php,v 1.1 2005/01/24 00:32:14 lastcraft Exp $
    
    class TestCaseWithParseError extends UnitTestCase {
        wibble
    }
    
?>